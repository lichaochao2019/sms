for i in xrange(30000000):
	pass
