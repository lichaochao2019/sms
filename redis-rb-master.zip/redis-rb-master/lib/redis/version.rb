class Redis
  VERSION = '4.1.3'
end
